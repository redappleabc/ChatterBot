API reference
==============

.. toctree::
    :maxdepth: 1
    :hidden:

    base
    specific
    facets
